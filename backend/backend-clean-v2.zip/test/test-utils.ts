import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import * as bcrypt from 'bcrypt';

export class TestUtils {
  public static async createTestApp(): Promise<INestApplication> {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    const app = moduleFixture.createNestApplication();
    
    // Enable global pipes and interceptors here if needed
    
    await app.init();
    return app;
  }

  public static async cleanDatabase(prisma: PrismaService): Promise<void> {
    // Clean up test data in reverse dependency order
    try {
      // Clean application-related tables first
      await prisma.applicationHistory.deleteMany();
      await prisma.applicationReview.deleteMany();
      await prisma.applicationDocument.deleteMany();
      await prisma.application.deleteMany();
    } catch (e) {
      console.log('Application tables not found, skipping...');
    }
    
    try {
      await prisma.document.deleteMany();
    } catch (e) {
      console.log('Document table not found, skipping...');
    }
    
    try {
      await prisma.scholarshipCycleCriteria.deleteMany();
      await prisma.scholarshipProgramCriteria.deleteMany();
      await prisma.studentRenewal.deleteMany();
      await prisma.studentScholarship.deleteMany();
      await prisma.scholarshipCycle.deleteMany();
      await prisma.scholarshipProgram.deleteMany();
    } catch (e) {
      console.log('Scholarship tables not found, skipping...');
    }
    
    try {
      // Clean role-specific profiles first
      await prisma.studentProfile.deleteMany();
      await prisma.reviewerProfile.deleteMany();
      await prisma.adminProfile.deleteMany();
      await prisma.sponsorProfile.deleteMany();
    } catch (e) {
      console.log('Role-specific profile tables not found, skipping...');
    }
    
    try {
      await prisma.profile.deleteMany();
    } catch (e) {
      console.log('Profile table not found, skipping...');
    }
    
    try {
      await prisma.sponsor.deleteMany();
    } catch (e) {
      console.log('Sponsor table not found, skipping...');
    }
    
    try {
      await prisma.user.deleteMany();
    } catch (e) {
      console.log('User table not found, skipping...');
    }
  }

  public static async createTestUser(
    prisma: PrismaService,
    userData: {
      email: string;
      password: string;
      firstName: string;
      lastName: string;
      role: 'STUDENT' | 'ADMIN' | 'SPONSOR' | 'REVIEWER';
    }
  ) {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    
    const user = await prisma.user.create({
      data: {
        email: userData.email,
        password: hashedPassword,
        role: userData.role,
        isActive: true,
      },
    });

    // Create base profile for all users
    const profile = await prisma.profile.create({
      data: {
        userId: user.id,
        firstName: userData.firstName,
        lastName: userData.lastName,
        phone: '+1234567890',
        address: '123 Test St',
        nationality: 'Test Country',
        dateOfBirth: new Date('1995-01-01'),
        gender: 'MALE',
      },
    });

    // Create role-specific profile
    if (userData.role === 'STUDENT') {
      await prisma.studentProfile.create({
        data: {
          profileId: profile.id,
          studentId: `STU${Date.now()}`,
          program: 'Computer Science',
          level: 'UNDERGRADUATE',
          yearOfStudy: 2,
          gpa: 3.5,
          institution: 'Test University',
          expectedGraduation: new Date('2025-06-01'),
        },
      });
    } else if (userData.role === 'REVIEWER') {
      await prisma.reviewerProfile.create({
        data: {
          profileId: profile.id,
          expertiseAreas: JSON.stringify(['Computer Science', 'Software Engineering']),
          department: 'Engineering',
          yearsExperience: 5,
          certifications: JSON.stringify(['PhD in Computer Science']),
          reviewQuota: 10,
          isActive: true,
        },
      });
    } else if (userData.role === 'ADMIN') {
      await prisma.adminProfile.create({
        data: {
          profileId: profile.id,
          permissions: JSON.stringify(['USER_MANAGEMENT', 'SCHOLARSHIP_MANAGEMENT']),
          managedDepartments: JSON.stringify(['Engineering', 'Computer Science']),
          accessLevel: 'STANDARD',
          lastLogin: new Date(),
        },
      });
    } else if (userData.role === 'SPONSOR') {
      await prisma.sponsorProfile.create({
        data: {
          profileId: profile.id,
          organizationName: 'Test Organization',
          position: 'Director',
          sponsorType: 'ORGANIZATION',
          totalContributed: 50000,
          preferredCauses: JSON.stringify(['STEM', 'Education']),
          isVerified: true,
        },
      });
    }

    // Create sponsor organization if user is a sponsor (keep existing logic)
    if (userData.role === 'SPONSOR') {
      await prisma.sponsor.create({
        data: {
          name: 'Test Organization',
          type: 'ORGANIZATION',
          contactPerson: `${userData.firstName} ${userData.lastName}`,
          email: userData.email,
          phone: '+1234567890',
          website: 'https://test.com',
          address: '123 Test St',
        },
      });
    }

    return user;
  }

  public static async createTestScholarship(
    prisma: PrismaService,
    sponsorUserId: string,
    scholarshipData?: Partial<{
      name: string;
      description: string;
      amount: number;
      totalSlots: number;
      availableSlots: number;
      applicationEndDate: Date;
    }>
  ) {
    // Find existing sponsor or create one
    let sponsor = await prisma.sponsor.findFirst();

    if (!sponsor) {
      // Create a sponsor if none exists
      sponsor = await prisma.sponsor.create({
        data: {
          name: 'Test Sponsor Org',
          type: 'ORGANIZATION',
          contactPerson: 'Test Contact',
          email: 'test@sponsor.com',
          phone: '+1234567890',
          address: 'Test Address',
        },
      });
    }
      
    // Create scholarship program first
    const program = await prisma.scholarshipProgram.create({
      data: {
        sponsorId: sponsor.id,
        name: scholarshipData?.name || 'Test Scholarship Program',
        description: scholarshipData?.description || 'Test scholarship program description',
        startYear: new Date().getFullYear(),
        defaultAmount: scholarshipData?.amount || 10000,
        defaultSlots: scholarshipData?.totalSlots || 5,
      },
    });

    // Create scholarship cycle
    return await prisma.scholarshipCycle.create({
      data: {
        programId: program.id,
        academicYear: '2025-2026',
        displayName: (scholarshipData?.name || 'Test Scholarship') + ' 2025-2026',
        amount: scholarshipData?.amount || 10000,
        currency: 'USD',
        totalSlots: scholarshipData?.totalSlots || 5,
        availableSlots: scholarshipData?.availableSlots || 5,
        applicationStartDate: new Date(),
        applicationEndDate: scholarshipData?.applicationEndDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        durationMonths: 12,
        disbursementSchedule: 'SEMESTER',
        status: 'OPEN',
      },
    });
  }

  public static async createTestApplication(
    prisma: PrismaService,
    studentUserId: string,
    scholarshipId: string,
    applicationData?: Partial<{
      status: string;
      personalStatement: string;
      gpa: number;
    }>
  ) {
    try {
      const applicationCount = await prisma.application.count();
      const applicationNumber = `APP-${Date.now()}-${applicationCount + 1}`;

      return await prisma.application.create({
        data: {
          applicationNumber,
          userId: studentUserId,
          cycleId: scholarshipId,
          status: applicationData?.status || 'DRAFT',
          motivationLetter: applicationData?.personalStatement || 'Test personal statement',
          submittedAt: applicationData?.status === 'SUBMITTED' || applicationData?.status === 'UNDER_REVIEW' 
            ? new Date() 
            : null,
        },
      });
    } catch (error) {
      console.warn('Application model not available yet, skipping application creation');
      return null;
    }
  }

  public static generateAuthToken(): string {
    // Mock JWT token for testing
    return 'Bearer mock-jwt-token';
  }

  public static createMockUser(role: 'STUDENT' | 'ADMIN' | 'SPONSOR' = 'STUDENT') {
    return {
      id: 'test-user-id',
      email: 'test@example.com',
      firstName: 'Test',
      lastName: 'User',
      role,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }
}